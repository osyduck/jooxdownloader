<?php
$c = curl_init('http://api.joox.com/web-fcgi-bin/web_get_songinfo?songid='.base64_decode($_GET['id']).'&lang=id&country=id&from_type=null&channel_id=null&_='.time());
	curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($c, CURLOPT_COOKIE, 'wmid=14997771; user_type=2; country=id; session_key=96870dd03ab9280c905566cad439c904;');
	curl_setopt($c, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36');
	$json = curl_exec($c);

	$json = str_replace('MusicInfoCallback(', '', $json);
	$json = str_replace(')', '', $json);
	$json = json_decode($json);
	$fi = $json->mp3Url;
	$sing = $json->msinger;
	$song = $json->msong;
	
$ch = curl_init('http://api.joox.com/web-fcgi-bin/web_lyric?musicid='.base64_decode(trim($_GET['id'])).'&lang=id&country=id&_='.time());
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36');
	$ly = curl_exec($ch);
	curl_close($ch);
	$ly = str_replace('MusicJsonCallback(', '', $ly);
	$ly = str_replace(')', '', $ly);
	$ly = json_decode($ly);
		$lyr = base64_decode($ly->lyric);
	
	$ly = str_replace('[999:00.00]***Lirik didapat dari pihak ketiga***', '[00:00.00]***Created By Janu***', base64_decode($ly->lyric));
	$ly = str_replace('[offset:0]', '', $ly);
	$file = "[Lyric] $song - $sing.lrc";
			$kopong = fopen($file, 'a');
			fwrite($kopong, "$ly");
			fclose($kopong);
			header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.basename($file));
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    unlink($file);
	?>